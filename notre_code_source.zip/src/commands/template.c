#include "../utils/utils.h"
#include "../utils/key.h"


// extern RsaKey global_key;
// extern SecretData global_sd;

uint8_t your_function(uint8_t * pt, uint8_t len) {

	// https://chipwhisperer.readthedocs.io/en/latest/simpleserial.html

    return 0;
}